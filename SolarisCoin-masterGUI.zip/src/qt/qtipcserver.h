#ifndef QTIPCSERVER_H
#define QTIPCSERVER_H

// Define solariscoin-Qt message queue name
#define solariscoinURI_QUEUE_NAME "solariscoinURI"

void ipcScanRelay(int argc, char *argv[]);
void ipcInit(int argc, char *argv[]);

#endif // QTIPCSERVER_H
